/*
 * @file main.h
 * @brief ...
 * @date Oct 19, 2022
 * @author ????
 */

#ifndef MAIN_H_
#define MAIN_H_

/**
 * @brief ...
 * @param[in] ...
 * @param[in]
 * @param[in] ...
 * @param[in]
 * 
 */
void constroiBitmaps (char *ends, char *arcof, char *f_acima, char *f_abaixo);

/**
 * @brief ...
 * @return ...
 */
int main();

#endif /* MAIN_H_ */
